import React, {Component} from 'react';
import fire from '../config/Fire';

import 'bootstrap/dist/css/bootstrap.min.css';
import { BrowserRouter as Router, Switch, Route, Link } from 'react-router-dom';


class Navbar extends Component {
    constructor(props) {
        super(props);
        this.logout = this.logout.bind(this);
    }

    logout = () => {
        fire.auth().signOut();
    }

    render() {
        return (
            <Router>
                <nav className="navbar navbar-expand-sm bg-dark navbar-dark">
                    <Link to={'/'} className="navbar-brand">IGD Rumah Sakit</Link>
                    <div className="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul className="navbar-nav mr-auto">
                        <li className="nav-item">
                        <Link  className="nav-link">Beranda</Link>
                        </li>
                        <li className="nav-item">
                        <Link  className="nav-link">Data Pasien</Link>
                        </li>
                    </ul>
                    <form className="form-inline my-2 my-lg-0">  
                        <button onClick={this.logout} className="btn btn-danger">Log out</button>
                    </form>
                    </div>
                </nav>
            </Router>   
        )
    }
}

export default Navbar;