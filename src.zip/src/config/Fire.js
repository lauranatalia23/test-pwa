import firebase from 'firebase';

const firebaseConfig = {
    apiKey: "AIzaSyCl_EgIGc_c65gvx2N1Rsyjz1tASQxr7ek",
    authDomain: "react-rs-pwa.firebaseapp.com",
    databaseURL: "https://react-rs-pwa.firebaseio.com",
    projectId: "react-rs-pwa",
    storageBucket: "react-rs-pwa.appspot.com",
    messagingSenderId: "323213535243"
};

const fire = firebase.initializeApp(firebaseConfig);
export default fire;